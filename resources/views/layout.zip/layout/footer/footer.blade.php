<footer class="main-footer">
    <div class="container">
    <div class="float-right d-none d-sm-block">
      <!-- <b>Version</b> 3.1.0 -->
    </div>
    <strong>Copyright &copy; Data Kemenag. 2021 Curalib All rights reserved.
    </div>
   
</footer>